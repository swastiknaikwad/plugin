# PluginAp

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 9.1.7.

As of now three static Pages to redirect on click of notification.

plug-in in the first page to serve.

service contain the data of notification.
