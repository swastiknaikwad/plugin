import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { PluginDataService } from '../services/plugin-data.service';

@Component({
  selector: 'app-plug-in',
  templateUrl: './plug-in.component.html',
  styleUrls: ['./plug-in.component.css']
})
export class PlugInComponent implements OnInit {

  numbe : any;
  notifyData: any [];

  constructor( private ps: PluginDataService, private router: Router, private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    this.notifyData = this.ps.getData();
    this.numbe = Object.keys(this.notifyData).length;
  }
  
  goTo(url) {
    this.router.navigate([`/${url}`]);
  }
}
