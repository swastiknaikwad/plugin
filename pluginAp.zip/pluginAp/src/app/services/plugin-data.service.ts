import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class PluginDataService {

  notify: any [] = [
    {
      name : "Ram",
      url: "page1"
    },
    {
      name : "Sham",
      url: "page2"
    },
    {
      name : "Kishan",
      url: "page3"
    }
  ]
  constructor(private router: Router) { }

  getData() {
    return (this.notify);
  }
  
  goToUrl(url)
  {
    this.router.navigate([`/${url}`]);

  }
}
